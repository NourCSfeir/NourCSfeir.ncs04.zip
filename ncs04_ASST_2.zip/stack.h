#include <iostream>
#include <vector>
using namespace std;
template < class T> class Stack ;
template < class T>

Stack <T> operator+(const Stack <T> &s1, const Stack <T> &s2){     
     /*
	Requires: 2 constant parameters: 2 constant stacks
	Effects: Returns the resulting stack after merging 2 stacks together
	
	Testing Strategy:
	Covers all possible stacks
    Partition on two empty stacks: Success
    Partition on two stacks, 1 is empty and 2 is non-empty: Success
    Partition on two stacks, 2 is empty and 1 is non-empty: Success
    Partition on two stacks of different sizes: Success
    Partition on two stacks of equal size: Success
    Partition on two stacks, 1 is char and 2 is int, or vice versa: Success
    Partition on two integer stacks: Success
	
	*/            
        Stack <T> result = s1;
        for (int i = 0; i < s1.elements.size (); i++) {
            result.elements.push_back(s2.elements[i]);
        }           
        return result ;
} 
template <class T>
class Stack{
    friend Stack <T> operator+<>(const Stack <T> &s1 , const Stack <T> & s2);
    std::vector <T> elements;

public :
    bool empty() const{ 
        /*
	Requires: no parameters
	Effects: Returns true if the stack is empty and false otherwise

	Testing Strategy:
	Covers all possible stacks
	Partition on an empty stack: Success
    Partition on a non-empty stack: Success
	*/
        return elements.empty();
    }
    void push(const T &element){
         /*
	Requires: a constant int or char 
	Effects: Adds the inputed constant on top of the stack

	Testing Strategy:
	Covers all possible elements
	Partition on real numbers:
		a- element = positive integer = 3: Success
		b- element = negative integer = -5: Success
		c- element = decimal = 4.7: Fail
	Partition on char = 'b': Success
	Partition on strings: Fail
	*/ 
        elements.push_back(element);}
    void pop(){
             /*
	Requires: no parameters
	Effects: Removes the element at the top of the stack

	Testing Strategy:
	Covers all possible stacks
	Partition on empty stacks: Success
    Partition on one element stack: Success
    Partition on more than one element stack: Success
	*/ 
        T last = elements.back();
        elements.pop_back();
    }
    T top(){
            /*
	Requires: no parameters
	Effects: Returns the element at the top of the stack

	Testing Strategy:
	Covers all possible stacks
	Partition on empty stacks: Fail
    Partition on one element stack: Success
    Partition on more than one element stack: Success
	*/ 
       T last = elements.back(); 
       return last; 
    }
};