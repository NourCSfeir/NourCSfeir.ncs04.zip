#include <iostream>
using namespace std;
struct node{
	int data;
	node *left;
	node *right;
};
class btree{
public:
	btree();
	void addNode(int key);	
	void inOrderPrint();
	void postOrderPrint();
	void preOrderPrint();
	int treeSize();
	int subtreeSize(int n);
	node* deleteNode(int n);
	private:
	void addNode(int key, node *current);
	void inOrderPrint(node *current);
	void postOrderPrint(node *current);
	void preOrderPrint(node *current);
	int treeSize(node* currentRoot);
	int subtreeSize(node* currentRoot, int n);
	node* deleteNode(node* current,int n);


	node* root;
};
btree::btree(){
	root = NULL;
}
void btree::addNode(int key, node *current){
	// Helper function for the below method.
		
	if(key < current->data){
		if(current->left != NULL){
			addNode(key, current->left);
		}else{
			current->left = new node;
			current->left->data = key;
			current->left->left = NULL;
			current->left->right = NULL;
		}
	}else if(key >= current->data){
		if(current->right != NULL){
			addNode(key, current->right);
		}else{
			current->right = new node;
			current->right->data = key;
			current->right->right = NULL;
			current->right->left = NULL;
		}
	}
}
void btree::addNode(int key){
	/*
	Requires: 1 parameter: the value of the node we want to add.
	Effects: Doesn't return, just adds the node to the tree in its correct position (satisfying the BST property). 
	
	Testing Strategy:
	Covers all possible keys of the node we want to add
	Partition on real numbers: Success
		a- key = positive integer = 3
		b- key = negative integer = -5
		c- key = decimal = 4.7
	Partition on char = 'b': Success 
	Partition on strings: Fail
	*/
	if(root != NULL){
		addNode(key, root);
	}else{
		root = new node;
		root->data = key;
		root->left = NULL;
		root->right = NULL;
	}
}
void btree::inOrderPrint(){
	/*
	Requires: Nothing
	Effects: Prints the elements of the tree in an "inorder" manner

	Testing Strategy:
	Covers possible trees that we want to print in an "inordered" manner
	Partition on real numbers: Success
		list = {15, 6, 72, 23, 45, 90, 68}
		InOrderTraversal: 6 15 23 45 68 72 90 
	Partition on strings: Fail
	*/
	inOrderPrint(root);
}
void btree::inOrderPrint(node *current){
	// Helper function for the above method.
	if(current != NULL){
		inOrderPrint(current->left);
		cout << current->data << " ";
		inOrderPrint(current->right);
	}
}
void btree::postOrderPrint(){
	/*
	Requires: Nothing
	Effects: Prints the elements of the tree in a "postorder" manner

	Testing Strategy:
	Covers possible trees that we want to print in a "postordered" manner
	Partition on real numbers: Success
		list = {15, 6, 72, 23, 45, 90, 68}
		PostOrderTraversal: 6 23 45 68 72 90 15 
	Partition on strings: Fail
	*/
	postOrderPrint(root);
	
}
void btree::postOrderPrint(node *current){
	// Helper function for the above method.

	if(current != NULL){
		inOrderPrint(current->left);
		inOrderPrint(current->right);
		cout << current->data << " ";
	}
}
void btree::preOrderPrint(){
	/*
	Requires: Nothing
	Effects: Prints the elements of the tree in a "preorder" manner

	Testing Strategy:
	Covers possible trees that we want to print in a "preordered" manner
	Partition on real numbers: Success
		list = {15, 6, 72, 23, 45, 90, 68}
		PreOrderTraversal: 15 6 23 45 68 72 90 
	Partition on strings: Fail
	*/
	preOrderPrint(root);
}
void btree::preOrderPrint(node *current){
	// Helper function for the above method.
	if(current != NULL){
		cout << current->data << " ";
		inOrderPrint(current->left);
		inOrderPrint(current->right);
	}
}
int btree::treeSize(node* currentRoot){
	// Helper function for the below method.
  if(currentRoot == NULL){
        return 0;
  }
  else
    return 1 + treeSize(currentRoot->left) + treeSize(currentRoot->right);
}
int btree::treeSize(){
	/*
	Requires: Nothing
	Effects: Returns the number of nodes in the tree

	Testing Strategy:
	Covers all possible trees that we want to get their size
	Partition on an empty tree: Success
	Partition on a single node tree: Success
	Partition on a tree with nodes > 1: Success
	Partition on a tree with node = NULL: Fail
	*/
	return treeSize(root);
	cout<<"\n";
} 
int btree::subtreeSize(node* currentRoot, int n){
	// Helper function for the below method.

	if(currentRoot == NULL){
		return 0;
	}
	else if(currentRoot->data == n){
		return treeSize(currentRoot);
	}
	else
		return subtreeSize(currentRoot->left, n) + subtreeSize(currentRoot->right, n);	  
}
int btree::subtreeSize(int n){
	/*
	Requires: value of the root node of the subtree we want to check its size for
	Effects: Returns the size of the subtree rooted at the inputed node

	Testing Strategy:
	Covers all possible subtrees that we want to get their size
	Partition on an empty subtree: Success
	Partition on a leaf node subtree: Success
	Partition on a non-leaf subtree: Success
	Partition on full tree: Success
	*/	
	return subtreeSize(root,n);
	cout<<"\n";
}
node* btree::deleteNode(node* current, int n){
	// Helper method for the function below
	if(current == NULL)
		return nullptr;
	current->left = deleteNode(current->left,n);
	current->right = deleteNode(current->right,n);
	if(current->data == n && current->left == NULL && current->right == NULL){
		return nullptr;
	}
	return 
		current;
}
node* btree::deleteNode(int n){
	/*
	Requires: value of the node (has to be a leaf) we want to delete
	Effects: Returns a pointer to the root of the tree after deleting the node with the inputed value

	Testing Strategy:
	Covers all the possible nodes that can be deleted from a tree
	Partition on an empty tree: Success
	Partition on a leaf node: Success
	Partition on a non-leaf node: Success (Although the method does not delete a non-leaf node, the method was designed to only work for leaf nodes.)
	Partition on a non-existing node: Success
	*/	
	node* current = root;
	return deleteNode(current,n);
}
