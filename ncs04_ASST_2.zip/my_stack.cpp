#include <iostream>
#include "stack.h"
int main(int argc, char const *argv[])
{
    Stack <int > a, b;
a.push('n');
a.push('s');

b.push(3);
b.push(4);
b.push(2);
Stack <int > c = a + b;
a.push(3);
a.pop();
cout << c.top();
    return 0;
}
