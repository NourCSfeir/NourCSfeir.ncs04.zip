#include <iostream>
#include "tree.h"
using namespace std;

int main(){

	btree *tree = new btree();
	tree->addNode(15);
	tree->addNode(6);
	tree->addNode(72);
	tree->addNode(23);
	tree->addNode(45);
	tree->addNode(90);
	tree->addNode(68);

    btree *tree1 = new btree();
    tree1->addNode(3);

	tree->preOrderPrint();
    cout << "\n";
	tree->inOrderPrint();
    cout << "\n";
	tree->postOrderPrint();
    cout << "\n";
    cout<<tree->treeSize()<<"\n";
    cout<<tree1->treeSize()<<"\n";
    tree->deleteNode(7);
    tree->postOrderPrint();
    cout<< "\n" << tree->subtreeSize(72);
}