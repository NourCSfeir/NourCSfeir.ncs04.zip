#include <iostream>
#include <map>
#include <vector>
#include <list>
using namespace std;

class graph {

int V; 
list<int> *adj; 
bool hasCycleUtil(int v, bool visited[], bool *rs);
public: 
graph(int V); 
bool hasCycle();

protected :
map<int, vector <int> > outgoing;
public :
 graph (const vector <int> &startPoints, const vector <int> &endPoints);
 int numOutgoing (const int nodeID) const ;
 const vector <int > &adjacent(const int nodeID) const;
 };
 graph::graph(int V)
{
    this->V = V;
    adj = new list<int>[V];
}
 graph::graph(const vector <int> &start, const vector <int> &end) {
    if(start.size() != end.size()) {
        throw invalid_argument(" The two vectors are not the same length.");
    }
    for(int i = 0; i < start.size(); i++){
        int starts = start[i], ends = end[i];
        outgoing[starts].push_back(ends);
        outgoing[ends];
    }
}
int graph::numOutgoing(const int nodeID) const{
     /*
	Requires: 1 constant parameter: 1 constant value at the vertex
	Effects: Returns the number of outgoing edges from nodeID

	Testing Strategy:
	Covers all possible vertices
    Partition on the first vertex with real number value in the graph: Success
    Partition on a graph with one vertex: Success
    Partition on a graph with more than one vertex: Success 
    Partition on an empty graph: Fail
    Partition on the last vertex on the graph: Success

	*/    
    return adjacent(nodeID).size(); 
}
const vector<int > &graph::adjacent(const int nodeID) const{
    /*
	Requires: 1 constant parameter: 1 constant value at the vertex
	Effects: Returns a constant vector of nodes to which nodeID has outgoing edges

	Testing Strategy:
	Covers all possible outgoing edges
    Partition on nodeID that has no outgoing edges: Success
    Partition on nodeID that has outgoing edges: Success 
	*/    
    map<int, vector <int> >:: const_iterator i = outgoing.find(nodeID);
    if(i == outgoing.end()){
        throw invalid_argument(" Invalid node ID!");
    }
    return i->second;
}
bool graph::hasCycleUtil(int v, bool visited[], bool *recStack){
    // Helper function for the below method.
    if(visited[v] == false)
    {
        visited[v] = true;
        recStack[v] = true;
        list<int>::iterator i;
        for(i = adj[v].begin(); i != adj[v].end(); ++i)
        {
            if (!visited[*i] && hasCycleUtil(*i, visited, recStack) )
                return true;
            else if (recStack[*i])
                return true;
        }
    } 
    recStack[v] = false; 
    return false;
}
bool graph::hasCycle(){
    /*
	Requires: no parameters
	Effects: Returns whether the graph has a cycle or not

	Testing Strategy:
	Covers all possible graphs
    Partition on a graph with no cycles: Success
    Partition on a graph with one cycle: Success 
    Partition on a graph with more than one cycle: Success  
    Partition on an empty graph: Fail
	*/    
    bool *visited = new bool[V];
    bool *recStack = new bool[V];
    for(int i = 0; i < V; i++)
    {
        visited[i] = false;
        recStack[i] = false;
    }
    for(int i = 0; i < V; i++)
        if (!visited[i] && hasCycleUtil(i, visited, recStack))
            return true;
    return false;
};
