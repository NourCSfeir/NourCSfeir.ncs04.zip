#include "graph.h"
#include <stdexcept>
#include <iostream>
#include <vector>
using namespace std;

int main(int argc, char const *argv[]){
     vector<int> vect;
     
    vect.push_back(0);
    vect.push_back(0);
    vect.push_back(0);
    vect.push_back(4);
    vect.push_back(4);
    vect.push_back(3);

     vector<int> vect2;
  
    vect2.push_back(1);
    vect2.push_back(2);
    vect2.push_back(3);
    vect2.push_back(3);
    vect2.push_back(1);
    vect2.push_back(0);

graph g = graph(vect, vect2);
cout<<g.numOutgoing(4)<<endl;
cout<<g.hasCycle();
    return 0;
}

